
const apiKey = "c25c766dbd404a57aa3b53b6abcba4b5"; // Your actual NewsAPI key
const url = `https://newsapi.org/v2/everything?q=politics&language=en&sortBy=publishedAt&pageSize=6&apiKey=${apiKey}`;

fetch(url)
    .then(response => response.json())
    .then(data => {
        const container = document.getElementById("news-container");
        container.innerHTML = "";
        data.articles.forEach(article => {
            const newsItem = document.createElement("article");
            newsItem.innerHTML = `
                <h2>${article.title}</h2>
                <p>${article.description || "No description available."}</p>
                <a href="${article.url}" target="_blank">Read more</a>
            `;
            container.appendChild(newsItem);
        });
    })
    .catch(error => {
        document.getElementById("news-container").innerHTML = "<p>Failed to load news. Please try again later.</p>";
        console.error("Error fetching news:", error);
    });
